document.addEventListener("DOMContentLoaded", () => {
    console.log("Page loaded successfully.");
});
