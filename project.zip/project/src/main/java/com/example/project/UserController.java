package com.example.project;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {
    @PostMapping("/login")
    public String login(@RequestBody User user) {
        return "Login successful!";
    }

    @PostMapping("/signup")
    public String signup(@RequestBody User user) {
        return "Signup successful!";
    }
}
